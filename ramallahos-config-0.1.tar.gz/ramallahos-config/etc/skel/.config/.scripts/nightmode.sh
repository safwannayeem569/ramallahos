source $HOME/.config/.scripts/keyboardbacklight.txt
case $b in

    0) brightnessctl set 40%  ; brightnessctl --device=asus::kbd_backlight set 3 && echo "b=3" > $HOME/.config/.scripts/keyboardbacklight.txt ;;
    1) brightnessctl set 100% ; brightnessctl --device=asus::kbd_backlight set 0 && echo "b=0" > $HOME/.config/.scripts/keyboardbacklight.txt ;;
    2) brightnessctl set 100% ; brightnessctl --device=asus::kbd_backlight set 0 && echo "b=0" > $HOME/.config/.scripts/keyboardbacklight.txt ;;
    3) brightnessctl set 100% ; brightnessctl --device=asus::kbd_backlight set 0 && echo "b=0" > $HOME/.config/.scripts/keyboardbacklight.txt ;;
esac
