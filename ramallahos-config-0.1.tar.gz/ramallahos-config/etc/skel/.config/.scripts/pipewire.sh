paru -R pavucontrol pavucontrol-qt pulseaudio pulseaudio-alsa pulseaudio-bluetooth pulseaudio-equalizer pulseaudio-equalizer-ladspa pulseaudio-jack pulseaudio-lirc pulseaudio-qt pulseaudio-rtp pulseaudio-support pulseaudio-zeroconf pulsemixer pulseaudio pulseaudio-alsa pulseaudio-bluetooth pulseaudio-equalizer pulseaudio-equalizer-ladspa pulseaudio-jack pulseaudio-lirc --disable-download-timeout --noconfirm --needed
paru -S pipewire pipewire-alsa pipewire-jack pipewire-media-session pipewire-pulse pipewire-support pipewire-zeroconf piper pipewire pipewire-alsa pipewire-jack pipewire-media-session pipewire-pulse pipewire-support pipewire-v4l2 pipewire-zeroconf --disable-download-timeout --noconfirm --needed


