source $HOME/.config/.scripts/touchpadtoggle.txt

case $a in
  0)xinput set-prop 15 "Device Enabled" 1 && echo "a=1" > $HOME/.config/.scripts/touchpadtoggle.txt ;;
  1)xinput set-prop 15 "Device Enabled" 0 && echo "a=0" > $HOME/.config/.scripts/touchpadtoggle.txt ;;
esac
