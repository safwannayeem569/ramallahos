sh -c "$(curl -fsSL https://raw.githubusercontent.com/Linuxbrew/install/master/install.sh)"
[ -d /home/linuxbrew/.linuxbrew ] && eval $(/home/linuxbrew/.linuxbrew/bin/brew shellenv) : echo -e "[ -d /home/linuxbrew/.linuxbrew ] && eval $(/home/linuxbrew/.linuxbrew/bin/brew shellenv)" >> .zshrc
mkdir -p /home/linuxbrew/.linuxbrew/var/homebrew/linked
chown -R $(whoami) /home/linuxbrew/.linuxbrew/var/homebrew/linked
