flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrep
flatpak remote-add --if-not-exists appcenter https://flatpak.elementary.io/repo.flatpakrepo
flatpak install flathub com.github.bcedu.vgrive \
network.loki.Session \
com.simplenote.Simplenote \
org.onionshare.OnionShare \
net.sourceforge.jpdftweak.jPdfTweak \
io.github.JaGoLi.ytdl_gui \
org.eclipse.Java \
fr.natron.Natron \
com.poweriso.PowerISO \
com.github.Eloston.UngoogledChromium \
net.unvanquished.Unvanquished \
com.github.alainm23.planner \
com.github.hezral.clips \
com.github.tenderowl.norka \
com.github.phase1geo.outliner \
com.github.phase1geo.textshine \
com.github.tenderowl.frog \
com.github.peteruithoven.resizer \
com.github.subhadeepjasu.ensembles \
com.github.childishgiant.mixer \
com.github.donadigo.eddy \
com.obsproject.Studio \
com.usebottles.bottles \
org.munadi.Munadi \
io.github.prateekmedia.appimagepool --system -y
