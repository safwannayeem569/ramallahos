paru -S lightdm-webkit2-glorious --noconfirm --needed
sudo systemctl enable lightdm-plymouth.service --force  \
sudo sed -i 's/^##greeter-session=example-gtk-gnome/greeter-session=lightdm-webkit2-greeter/' /etc/lightdm/lightdm.conf  \
sudo sed -i 's/^webkit_theme\s*=\s*\(.*\)/webkit_theme = glorious ##\1/g' /etc/lightdm/lightdm-webkit2-greeter.conf  \
sudo sed -i 's/^debug_mode\s*=\s*\(.*\)/debug_mode = true ##\1/g' /etc/lightdm/lightdm-webkit2-greeter.conf  \
sudo mv /usr/share/xsessions/gnome.desktop /usr/share/xsessions/gnome.desktop.disabled  \
kwriteconfig5 --file kscreenlockerrc --group Greeter --group LnF --group General --key showMediaControls --type bool false

