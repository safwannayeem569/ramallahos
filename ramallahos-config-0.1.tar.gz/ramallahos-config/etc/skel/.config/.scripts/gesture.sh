paru -S libinput-gestures libinput_gestures_qt gestures fusuma --noconfirm --needed
sudo gpasswd -a $USER input
libinput-gestures-setup autostart \
libinput-gestures-setup start
echo -e 'gesture swipe left 4 xdotool key alt+Right
gesture swipe right 4 xdotool key alt+Left
gesture swipe up 3 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "Expose"
gesture swipe down 3 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "ShowDesktopGrid"
gesture swipe down 4 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "Window Minimize"
gesture swipe up 4 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "Window Maximize"
gesture swipe left 3 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "Switch to Next Desktop"
gesture swipe right 3 qdbus org.kde.kglobalaccel /component/kwin invokeShortcut "Switch to Previous Desktop"
gesture pinch in 3 xkill
gesture pinch out 3 xdotool key alt+0x0020' >> ~/.config/libinput-gestures.conf
sudo mkdir -p ~/.config/fusuma
echo -e "pinch:
  2:
    in:
      command: "xdotool keydown ctrl click 4 keyup ctrl" ## threshold: 0.5, interval: 0.5
    out:
      command: "xdotool keydown ctrl click 5 keyup ctrl" ## threshold: 0.5, interval: 0.5
threshold:
  pinch: 0.7
interval:
  swipe: 0.75
  pinch: 0.7" >> ~/.config/fusuma/config.yml
sudo mkdir -p ~/Resources
