pamixer -d 5
