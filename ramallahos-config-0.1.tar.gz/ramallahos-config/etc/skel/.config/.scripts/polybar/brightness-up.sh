brightnessctl set 10%+ 
