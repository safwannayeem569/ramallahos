brightnessctl set 10%-
