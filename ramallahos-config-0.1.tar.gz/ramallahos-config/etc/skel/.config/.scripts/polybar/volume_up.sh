pamixer -i 5
