paru -R timeshift timeshift-autosnap --disable-download-timeout --noconfirm --needed
paru -S snapper snapper-support snapper-gui-git --disable-download-timeout --noconfirm --needed
