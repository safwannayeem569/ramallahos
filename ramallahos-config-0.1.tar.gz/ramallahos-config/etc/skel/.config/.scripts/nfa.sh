echo -ne '
DISTRIB_DESCRIPTION="SafwanOS"
DISTRIB_ID="SafwanOS"
DISTRIB_RELEASE="rolling"
' > /etc/lsb-release

echo -ne '
NAME=SafwanOS
VERSION="0.1"
ID=SafwanOS
VERSION_ID=0.1
PRETTY_NAME="SafwanOS 0.1"
ANSI_COLOR="0;38;2;60;110;180"
' > /etc/os-release

echo -ne '
alias neofetch="neofetch --source $HOME/.config/neofetch/sos.txt"
' >> $HOME/.zshrc
