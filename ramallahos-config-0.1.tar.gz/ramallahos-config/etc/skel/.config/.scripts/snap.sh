sudo systemctl enable --now snapd.socket
sudo ln -s /var/lib/snapd/snap /snap
sudo systemctl start --now snapd.socket
sudo snap install argos-translate cornyjokes whatami rambox nimblenote speedy-duplicate-finder onenote-desktop sosumi taskade

