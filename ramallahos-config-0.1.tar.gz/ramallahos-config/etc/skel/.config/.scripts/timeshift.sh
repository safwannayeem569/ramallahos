paru -R snapper snapper-support snapper-gui-git --disable-download-timeout --noconfirm --needed
paru -S timeshift timeshift-autosnap --disable-download-timeout --noconfirm --needed
