#!/bin/env bash
killall -9 variety xfce4-power-manager dunst sxhkd eww variety nm-applet pamac-tray xfce4-power-manager volumeicon blueberry-tray caffeine-ng-git udiskie dunst sxhkd gammy parcellite edges conky picom albert gufw polybar
xsetroot -cursor_name left_ptr &
# dex $HOME/.config/autostart/arcolinux-welcome-app.desktop &
# feh --bg-fill /usr/share/backgrounds/arcolinux/arco-wallpaper.jpg &
variety &
nm-applet &
xfce4-power-manager &
blueberry-tray &
caffeine-ng-git &
udiskie &
dunst -config $HOME/.config/dunst/dunstrc &
sxhkd &
lxsession &
gammy &
parcellite &
edges &
/usr/bin/emacs --daemon &
picom --config $HOME/.xmonad/picom.conf &
albert &
gufw &
kmix &
polybar -q main -c ~/.config/polybar/grayblocks.ini &





