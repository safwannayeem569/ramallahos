curl -O https://blackarch.org/strap.sh
echo 8bfe5a569ba7d3b055077a4e5ceada94119cccef
strap.sh | sha1sum -c
chmod +x strap.sh
sudo ./strap.sh
sudo pacman -Syu
sudo pacman -Syyu --needed blackarch --overwrite='*'
