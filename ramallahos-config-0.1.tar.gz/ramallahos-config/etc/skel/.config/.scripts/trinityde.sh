sudo pacman-key --recv-keys 0x8685AD8B
sudo echo -e "
[trinity]
Server = https://mirror.ppa.trinitydesktop.org/trinity/archlinux" >> /etc/pacman.conf
paru -S --noconfirm --needed tde-tdebase
