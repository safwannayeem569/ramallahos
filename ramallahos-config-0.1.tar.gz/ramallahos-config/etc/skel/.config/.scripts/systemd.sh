sudo systemctl enable smb.service nmb.service libvertd cronie.service systemd-timesyncd cups bluetooth sshd dhcpcd.service NetworkManager.service ntpd.service cups.service ufw teamviewerd.service fstrim.timer --now
sudo sysctl vm.swappiness=10
sudo ufw enable
sudo ntpd -qg
sudo systemctl disable dhcpcd.service

