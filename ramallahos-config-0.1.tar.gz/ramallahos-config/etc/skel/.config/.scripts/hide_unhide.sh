source ~/.config/.scripts/hide_unhide.txt
case $h in
    0)bspc node focused -g hidden=on && echo "h=1" > ~/.config/.scripts/hide_unhide.txt ;;
    1)bspc node $(bspc query -N -n .hidden | tail -n1) -g hidden=off && echo "h=0" > ~/.config/.scripts/hide_unhide.txt ;;
esac

